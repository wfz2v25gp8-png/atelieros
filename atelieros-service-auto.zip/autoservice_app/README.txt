AtelierOS — prototip web pentru management service auto

PORNIRE
1. Descarcă și dezarhivează atelieros-service-auto.zip.
2. Deschide index.html în Chrome, Safari, Edge sau Firefox.
3. Nu necesită instalare, cont sau conexiune la internet pentru funcțiile incluse.

FUNCȚII
- Dashboard cu indicatori și programările zilei
- Programări: adăugare, editare, status, transformare în comandă de lucru
- Comenzi de lucru: client, vehicul, km, reclamație, diagnoză, mecanic, status, poziții și calcule
- Devize: poziții, TVA configurabil, acceptare/refuz, tipărire/salvare PDF prin dialogul browserului
- Facturi demonstrative: poziții, scadență, status achitat/restant, tipărire/salvare PDF
- Clienți și vehicule: adăugare și editare
- Setări firmă și TVA, export CSV, backup/import JSON

LIMITĂRI IMPORTANTE
Aceasta este o versiune MVP locală: datele se salvează în localStorage-ul browserului/dispozitivului. Nu există încă utilizatori, sincronizare cloud, acces simultan între dispozitive, control de acces, backup automat sau integrare RO e-Factura. Facturile sunt documente demonstrative și nu trebuie considerate facturi fiscale conforme. Înainte de folosire comercială sunt necesare backend securizat, bază de date, autentificare și validarea cerințelor fiscale/contabile din România.
