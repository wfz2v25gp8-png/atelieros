-- AtelierOS: tabel de date per utilizator, cu Row Level Security activ.
-- Rulează acest script în Supabase > SQL Editor > New query.
create table if not exists public.atelieros_data (
  user_id uuid primary key references auth.users(id) on delete cascade,
  payload jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);

alter table public.atelieros_data enable row level security;

-- Fiecare cont poate citi doar propriul rând.
create policy "Users can read own AtelierOS data"
  on public.atelieros_data for select
  to authenticated
  using (auth.uid() = user_id);

-- Fiecare cont poate crea doar propriul rând.
create policy "Users can insert own AtelierOS data"
  on public.atelieros_data for insert
  to authenticated
  with check (auth.uid() = user_id);

-- Fiecare cont poate actualiza doar propriul rând.
create policy "Users can update own AtelierOS data"
  on public.atelieros_data for update
  to authenticated
  using (auth.uid() = user_id)
  with check (auth.uid() = user_id);
