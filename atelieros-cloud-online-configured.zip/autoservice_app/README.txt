ATELIEROS — instalare GitHub Pages + Supabase

FIȘIERE
- index.html: aplicația AtelierOS
- config.js: deja configurat cu Project URL și cheia publică trimise de tine
- supabase-schema.sql: tabelele și regulile de securitate

1. ÎNCĂRCARE ÎN GITHUB
În repository https://github.com/wfz2v25gp8-png/atelieros, în rădăcina repository-ului, înlocuiește index.html și config.js cu versiunile din acest pachet. Asigură-te că supabase-schema.sql este de asemenea încărcat. Nu încărca doar ZIP-ul; fișierele trebuie să fie individuale.

2. CONFIGURARE OBLIGATORIE ÎN SUPABASE
Încărcarea fișierelor în GitHub nu creează automat tabelele din baza de date.
- Deschide https://supabase.com/dashboard/project/nuafmvxeaidnzqnixoob/sql/new
- Deschide fișierul supabase-schema.sql și copiază tot conținutul.
- Lipește-l în SQL Editor și apasă Run.
- Verifică să apară succes, fără erori.

3. PUBLICARE
În GitHub: Settings > Pages > Deploy from a branch > main > /(root) > Save.
Așteaptă terminarea rulării din Actions, apoi deschide:
https://wfz2v25gp8-png.github.io/atelieros/
Reîncarcă pagina dacă era deja deschisă.

4. CONTURI
În aplicație, apasă Creează cont și folosește un email la care ai acces și o parolă puternică. Dacă Supabase cere confirmare, confirmă emailul înainte să te conectezi.

SECURITATE ȘI LIMITĂRI
- Cheia inclusă este cheia publică publishable, destinată frontend-ului. Nu pune niciodată service_role sau secret key în GitHub.
- Politicile RLS din script limitează accesul la datele contului autentificat.
- Dacă ai probleme la creare cont, verifică setările de confirmare email din Supabase Authentication.
- Păstrează backup JSON periodic din Setări service.
- Documentele de factură sunt demonstrative, nu o integrare fiscală/RO e-Factura.
