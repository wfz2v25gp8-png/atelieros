/*
 * AtelierOS — configurare Supabase
 * Cheia publishable este destinată aplicației din browser.
 * Nu introduce aici service_role sau o secret key.
 */
window.ATELIEROS_CONFIG = {
  supabaseUrl: "https://nuafmvxeaidnzqnixoob.supabase.co",
  supabaseAnonKey: "sb_publishable_EdNS-p3qMnv7PLj9DK877w_dAn2aNiK"
};
