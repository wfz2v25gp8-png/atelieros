ATELIEROS — instalare GitHub Pages + Supabase

CE CONȚINE
- index.html: aplicația AtelierOS
- config.js: URL-ul proiectului Supabase și cheia publică
- supabase-schema.sql: tabelul online și regulile de securitate

PASUL 1 — CONFIGUREAZĂ SUPABASE
1. Creează un proiect la https://supabase.com/ și așteaptă să fie gata.
2. Deschide SQL Editor > New query.
3. Copiază tot conținutul din supabase-schema.sql, rulează-l (Run) și verifică să nu apară eroare.
4. Deschide Project Settings > API (sau Connect / API Keys).
5. Copiază Project URL și cheia publică anon/publishable. NU folosi service_role sau secret key.
6. Deschide config.js și înlocuiește valorile INTRODU_AICI... cu cele copiate.

PASUL 2 — ÎNCARCĂ ÎN GITHUB
În repository-ul https://github.com/wfz2v25gp8-png/atelieros trebuie să existe la nivelul principal:
- index.html
- config.js
- supabase-schema.sql (nu este necesar ca site-ul să funcționeze, dar păstrează-l în repo)
Nu încărca doar arhiva ZIP. Încarcă fișierele individual sau înlocuiește-le pe cele vechi.

PASUL 3 — PUBLICARE
GitHub > repository > Settings > Pages > Source: Deploy from a branch > main > /(root) > Save.
Așteaptă finalizarea publicării la Actions, apoi deschide:
https://wfz2v25gp8-png.github.io/atelieros/
Dacă ai schimbat config.js, reîncarcă pagina și încearcă o reîmprospătare completă.

PASUL 4 — CONT
În pagina AtelierOS, creează cont cu email și parolă. Dacă Supabase cere confirmarea emailului, confirmă mesajul primit și apoi conectează-te.
Datele aplicației sunt sincronizate în tabelul atelieros_data, câte un rând per utilizator autentificat. Regulile RLS limitează accesul la rândul propriu.

NOTE IMPORTANTE
- Fără URL și cheia publică din propriul proiect Supabase, autentificarea online nu poate funcționa. Cheia publică este destinată frontend-ului; nu publica niciodată cheia service_role/secret.
- Configurarea Supabase trebuie făcută înainte de folosire.
- Folosește o parolă puternică și activează confirmarea emailului.
- Această versiune sincronizează datele AtelierOS per cont. Nu este încă o platformă completă multi-service cu invitații/roluri, iar facturile generate sunt documente demonstrative, nu integrare fiscală/RO e-Factura.
- Păstrează backup JSON periodic din Setări service.
