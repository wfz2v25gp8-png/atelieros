/*
 * AtelierOS — configurare Supabase
 * Înlocuiește cele două valori cu Project URL și cheia publică anon/publishable
 * din Supabase > Project Settings > API (sau Connect/API Keys, în funcție de interfață).
 * NU pune aici cheia service_role / secret key.
 */
window.ATELIEROS_CONFIG = {
  supabaseUrl: "INTRODU_AICI_SUPABASE_PROJECT_URL",
  supabaseAnonKey: "INTRODU_AICI_CHEIA_PUBLICA_SUPABASE"
};
