# Instalare și integrare AtelierOS

## 1. Creează proiectul Supabase
1. Intră pe https://supabase.com și creează un proiect.
2. Deschide SQL Editor.
3. Copiază și execută integral `supabase/schema.sql`.
4. Din Project Settings → API / Connect, copiază Project URL și cheia publică (publishable key; în proiectele mai vechi poate apărea ca `anon` key).

## 2. Configurează URL-urile de autentificare
În Authentication → URL Configuration:
- Site URL: `https://wfz2v25gp8-png.github.io`
- Redirect URLs: `https://wfz2v25gp8-png.github.io/atelieros/`

Dacă folosești alt URL de publicare, înlocuiește valorile cu URL-ul tău real.

## 3. Adaugă clientul în proiect
Copiază `js/atelieros-supabase.js` în repo, de exemplu în `js/atelieros-supabase.js`.

În `index.html`, înainte de scripturile care îl folosesc, adaugă:

```html
<script src="https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2"></script>
<script src="./js/atelieros-supabase.js"></script>
<script>
  AtelierOSBackend.configure({
    url: "https://PROJECT-REF.supabase.co",
    publishableKey: "CHEIA_PUBLICA_SUPABASE"
  });
</script>
```

Înlocuiește URL-ul și cheia cu valorile din proiectul tău. Cheia publishable/anon poate fi publică numai dacă RLS este activ și configurat corect.

## 4. Fluxul de onboarding
1. Utilizatorul se înregistrează cu email și parolă.
2. Confirmă emailul, dacă ai activat confirmarea.
3. Se autentifică.
4. Creează profilul service-ului prin `AtelierOSBackend.createWorkshop("Numele service-ului")`.
5. Păstrează `id` returnat ca `workshop_id` pentru operațiile din sesiunea curentă. Nu îl folosi ca un substitut pentru securitate; baza de date verifică apartenența prin RLS.

Exemplu:
```js
const { data, error } = await AtelierOSBackend.signUp("email@example.com", "o-parola-puternica");
if (error) console.error(error);

const { data: login, error: loginError } =
  await AtelierOSBackend.signIn("email@example.com", "o-parola-puternica");

const { data: workshop, error: workshopError } =
  await AtelierOSBackend.createWorkshop("Service Exemplu");
```

## 5. Funcții disponibile
- `signUp(email, password)`
- `signIn(email, password)`
- `signOut()`
- `getSession()`
- `createWorkshop(name)`
- `listMyWorkshops()`
- `addCustomer(workshopId, customer)`
- `listCustomers(workshopId)`
- `addVehicle(workshopId, vehicle)`
- `listVehicles(workshopId)`
- `addAppointment(workshopId, appointment)`
- `listAppointments(workshopId)`
- `addWorkOrder(workshopId, workOrder)`
- `listWorkOrders(workshopId)`

Exemplu de client:
```js
await AtelierOSBackend.addCustomer(workshopId, {
  full_name: "Ion Popescu",
  phone: "07xxxxxxxx",
  email: "ion@example.com"
});
```

Exemplu de mașină:
```js
await AtelierOSBackend.addVehicle(workshopId, {
  customer_id: "UUID_CLIENT",
  registration_number: "B-123-ABC",
  make: "Dacia",
  model: "Logan",
  year: 2020,
  vin: "VIN_DACA_E_CUNOSCUT"
});
```

## 6. Integrarea cu ecranele existente
Conectează formularele actuale la funcțiile de mai sus:
- formularul de autentificare → `signIn`
- formularul de înregistrare → `signUp`
- formularul de client → `addCustomer`
- formularul de mașină → `addVehicle`
- programare nouă → `addAppointment`
- comandă de lucru nouă → `addWorkOrder`

La încărcarea secțiunilor, citește datele din backend și construiește lista din rezultatul funcției `list...`, nu din date demonstrative sau `localStorage`.

## 7. Teste obligatorii
- Creează două conturi și două service-uri.
- Adaugă un client în primul service.
- Autentifică-te în al doilea service și verifică faptul că primul client nu apare.
- Încearcă să citești/editezi datele primului service din contul celui de-al doilea: cererea trebuie refuzată.
- Verifică resetarea parolei și confirmarea emailului.

Acest pachet este fundația backend-ului; nu transformă automat fiecare buton din interfața curentă. Pentru conectarea exactă a tuturor ecranelor, este nevoie de sursa actuală a proiectului.
