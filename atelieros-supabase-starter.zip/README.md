# AtelierOS — pachet de conectare Supabase

Acest pachet adaugă fundația pentru autentificare și date online fără să înlocuiască interfața existentă.

## Fișiere
- `supabase/schema.sql` — tabele, politici RLS și funcția pentru crearea service-ului.
- `js/atelieros-supabase.js` — clientul Supabase și funcții pentru conturi, service-uri, clienți, mașini, programări și comenzi de lucru.
- `INTEGRARE.md` — pașii de instalare și integrare.

## Înainte de a începe
Site-ul curent este publicat ca pagină statică pe GitHub Pages. Nu am putut descărca sursa repo-ului din mediul de lucru, așa că pachetul este un modul de integrare separat și nu rescrie `index.html`. Pentru integrarea exactă în interfața curentă, este necesar fișierul `index.html` sau arhiva proiectului.

## Securitate
- În browser se folosește numai cheia publică/publishable Supabase.
- Nu pune niciodată `service_role` sau o cheie secretă în HTML/JavaScript public.
- Politicile RLS din SQL sunt obligatorii.
- Configurează confirmarea emailului și URL-urile de redirecționare în Supabase Auth.
- Înainte de folosirea cu date reale, testează cu două conturi de service diferite.
