/*
 * AtelierOS Supabase client.
 * Browser-safe only with the publishable/anon key and RLS enabled.
 * Never put a Supabase secret/service_role key in this file.
 */
(function (global) {
  "use strict";

  let client = null;

  function requireClient() {
    if (!client) {
      throw new Error("AtelierOSBackend nu este configurat. Apelează configure({ url, publishableKey }).");
    }
    return client;
  }

  function configure(config) {
    if (!global.supabase || typeof global.supabase.createClient !== "function") {
      throw new Error("Lipsește SDK-ul Supabase. Încarcă supabase-js v2 înaintea acestui fișier.");
    }
    if (!config || !config.url || !config.publishableKey) {
      throw new Error("Sunt necesare url și publishableKey din proiectul Supabase.");
    }
    client = global.supabase.createClient(config.url, config.publishableKey, {
      auth: {
        persistSession: true,
        autoRefreshToken: true,
        detectSessionInUrl: true
      }
    });
    return client;
  }

  async function insertForWorkshop(table, workshopId, payload) {
    if (!workshopId) throw new Error("Lipsește workshopId.");
    const { data, error } = await requireClient()
      .from(table)
      .insert({ ...payload, workshop_id: workshopId })
      .select()
      .single();
    return { data, error };
  }

  async function listForWorkshop(table, workshopId) {
    if (!workshopId) throw new Error("Lipsește workshopId.");
    const { data, error } = await requireClient()
      .from(table)
      .select("*")
      .eq("workshop_id", workshopId)
      .order("created_at", { ascending: false });
    return { data, error };
  }

  const api = {
    configure,

    async signUp(email, password) {
      return requireClient().auth.signUp({
        email: String(email).trim(),
        password
      });
    },

    async signIn(email, password) {
      return requireClient().auth.signInWithPassword({
        email: String(email).trim(),
        password
      });
    },

    async signOut() {
      return requireClient().auth.signOut();
    },

    async getSession() {
      return requireClient().auth.getSession();
    },

    async getUser() {
      return requireClient().auth.getUser();
    },

    onAuthStateChange(callback) {
      return requireClient().auth.onAuthStateChange(callback);
    },

    async createWorkshop(name) {
      return requireClient().rpc("create_workshop", {
        workshop_name: String(name || "").trim()
      });
    },

    async listMyWorkshops() {
      const { data: userResult, error: userError } = await requireClient().auth.getUser();
      if (userError) return { data: null, error: userError };
      if (!userResult.user) return { data: null, error: new Error("Trebuie să fii autentificat.") };

      return requireClient()
        .from("workshop_members")
        .select("workshop_id, role, workshops(id, name, created_at)")
        .eq("user_id", userResult.user.id);
    },

    addCustomer(workshopId, customer) {
      return insertForWorkshop("customers", workshopId, customer);
    },
    listCustomers(workshopId) {
      return listForWorkshop("customers", workshopId);
    },

    addVehicle(workshopId, vehicle) {
      return insertForWorkshop("vehicles", workshopId, vehicle);
    },
    listVehicles(workshopId) {
      return listForWorkshop("vehicles", workshopId);
    },

    addAppointment(workshopId, appointment) {
      return insertForWorkshop("appointments", workshopId, appointment);
    },
    listAppointments(workshopId) {
      return listForWorkshop("appointments", workshopId);
    },

    addWorkOrder(workshopId, workOrder) {
      return insertForWorkshop("work_orders", workshopId, workOrder);
    },
    listWorkOrders(workshopId) {
      return listForWorkshop("work_orders", workshopId);
    }
  };

  global.AtelierOSBackend = api;
})(window);
